import axios from 'axios'

import { frameworkBaseUrl } from './framework'

/** 为指定框架创建一个 axios 实例。 */
export function apiFor(framework) {
  return axios.create({
    baseURL: frameworkBaseUrl(framework),
    timeout: 120000,
    headers: { 'Content-Type': 'application/json' },
  })
}
