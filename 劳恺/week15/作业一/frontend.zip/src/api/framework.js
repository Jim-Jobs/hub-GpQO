/** 两套框架的前端元数据与地址解析。 */

export const FRAMEWORKS = {
  langgraph: {
    key: 'langgraph',
    label: 'LangGraph',
    envKey: 'VITE_LANGGRAPH_API_URL',
    fallback: 'http://localhost:8000',
  },
  openai_agents: {
    key: 'openai_agents',
    label: 'OpenAI Agents SDK',
    envKey: 'VITE_AGENTS_SDK_API_URL',
    fallback: 'http://localhost:9000',
  },
}

export const FRAMEWORK_LIST = Object.values(FRAMEWORKS)

export function getFrameworkMeta(framework) {
  return FRAMEWORKS[framework] || FRAMEWORKS.langgraph
}

/** 取当前框架对应的编排器地址。 */
export function frameworkBaseUrl(framework) {
  const meta = getFrameworkMeta(framework)
  return import.meta.env[meta.envKey] || meta.fallback
}
