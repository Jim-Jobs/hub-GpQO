import { frameworkBaseUrl } from './framework'

/** 解析一段 SSE 文本，返回 { event, data } 或 null。 */
function parseEventBlock(block) {
  let event = ''
  const dataLines = []

  for (const line of block.split('\n')) {
    if (line.startsWith('event:')) {
      event = line.slice(6).trim()
    } else if (line.startsWith('data:')) {
      dataLines.push(line.slice(5).trim())
    }
  }

  if (!event) return null

  const raw = dataLines.join('\n')
  let data = {}
  if (raw) {
    try {
      data = JSON.parse(raw)
    } catch (error) {
      data = { raw }
    }
  }
  return { event, data }
}

/**
 * 发送消息并消费 SSE 事件流。
 * 用 fetch 而不是 EventSource，因为 EventSource 只支持 GET。
 */
export async function streamChat({ framework, conversationId, message, onEvent, signal }) {
  const url = `${frameworkBaseUrl(framework)}/api/chat/stream`
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      conversation_id: conversationId || null,
      message,
    }),
    signal,
  })

  if (!response.ok) {
    let detail = ''
    try {
      const body = await response.json()
      detail = body.detail || ''
    } catch (error) {
      detail = ''
    }
    throw new Error(detail || `请求失败（HTTP ${response.status}）`)
  }
  if (!response.body) {
    throw new Error('浏览器不支持流式响应')
  }

  const reader = response.body.getReader()
  const decoder = new TextDecoder('utf-8')
  let buffer = ''

  while (true) {
    const { done, value } = await reader.read()
    if (done) break

    buffer += decoder.decode(value, { stream: true })

    let separator = buffer.indexOf('\n\n')
    while (separator !== -1) {
      const block = buffer.slice(0, separator)
      buffer = buffer.slice(separator + 2)
      const parsed = parseEventBlock(block)
      if (parsed) onEvent(parsed)
      separator = buffer.indexOf('\n\n')
    }
  }

  // 处理结尾没有换行符的最后一块
  const tail = parseEventBlock(buffer)
  if (tail) onEvent(tail)
}
