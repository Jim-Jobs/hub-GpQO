<script setup>
import { computed } from 'vue'

import { STAGE_LABELS, useConversationStore } from '@/stores/conversation'

const store = useConversationStore()

const EMOTION_LABELS = { positive: '正向', negative: '负向' }
const STRATEGY_LABELS = { encouragement: '鼓励', empathy: '共情', support: '安全支持' }

const timeline = computed(() => store.timeline)

function lastEvent(name) {
  const found = [...timeline.value].reverse().find((item) => item.event === name)
  return found ? found.data : null
}

const emotion = computed(() => lastEvent('emotion_analysis') && lastEvent('emotion_completed'))
const qualityChecks = computed(() =>
  timeline.value.filter((item) => item.event === 'quality_check').map((item) => item.data),
)
const lastQuality = computed(() => qualityChecks.value[qualityChecks.value.length - 1] || null)
const retryCount = computed(
  () => timeline.value.filter((item) => item.event === 'retrying').length,
)
const failed = computed(() => lastEvent('failed'))

const steps = computed(() => {
  const events = timeline.value.map((item) => item.event)
  const has = (name) => events.includes(name)
  return [
    {
      key: 'emotion',
      label: 'Agent 1 · 情绪识别',
      state: has('emotion_completed') ? 'done' : has('emotion_analysis') ? 'active' : 'pending',
    },
    {
      key: 'response',
      label: 'Agent 2 · 情绪响应',
      state: has('quality_check') ? 'done' : has('response_generation') ? 'active' : 'pending',
    },
    {
      key: 'quality',
      label: 'FastAPI · 质量检查',
      state: has('quality_check')
        ? lastQuality.value && lastQuality.value.passed
          ? 'done'
          : 'warn'
        : 'pending',
    },
  ]
})
</script>

<template>
  <section class="status-panel">
    <header class="status-panel__header">
      <h2 class="status-panel__title">Agent 执行过程</h2>
      <span v-if="store.streaming" class="status-panel__badge status-panel__badge--running">
        运行中
      </span>
      <span v-else-if="failed" class="status-panel__badge status-panel__badge--error">失败</span>
      <span v-else-if="timeline.length" class="status-panel__badge status-panel__badge--done">
        已完成
      </span>
    </header>

    <ol class="status-steps">
      <li
        v-for="step in steps"
        :key="step.key"
        class="status-step"
        :class="`status-step--${step.state}`"
      >
        <span class="status-step__dot" />
        <span class="status-step__label">{{ step.label }}</span>
      </li>
    </ol>

    <div v-if="timeline.length" class="status-facts">
      <div v-if="emotion" class="status-fact">
        <span class="status-fact__key">情绪</span>
        <span class="status-fact__value">
          {{ EMOTION_LABELS[emotion.emotion] || emotion.emotion }}
          <template v-if="emotion.emotion_type">· {{ emotion.emotion_type }}</template>
        </span>
      </div>
      <div v-if="emotion" class="status-fact">
        <span class="status-fact__key">置信度</span>
        <span class="status-fact__value">
          {{ (emotion.confidence * 100).toFixed(0) }}%
        </span>
      </div>
      <div v-if="lastQuality" class="status-fact">
        <span class="status-fact__key">策略</span>
        <span class="status-fact__value">
          {{ STRATEGY_LABELS[lastQuality.strategy] || lastQuality.strategy || '—' }}
        </span>
      </div>
      <div v-if="lastQuality" class="status-fact">
        <span class="status-fact__key">质量检查</span>
        <span
          class="status-fact__value"
          :class="lastQuality.passed ? 'is-ok' : 'is-bad'"
        >
          {{ lastQuality.passed ? '通过' : '未通过' }}
        </span>
      </div>
      <div v-if="retryCount" class="status-fact">
        <span class="status-fact__key">重试</span>
        <span class="status-fact__value">{{ retryCount }} 次</span>
      </div>
      <div v-if="failed" class="status-fact">
        <span class="status-fact__key">错误</span>
        <span class="status-fact__value is-bad">{{ failed.error }}</span>
      </div>
    </div>

    <details v-if="timeline.length" class="status-events">
      <summary>事件明细（{{ timeline.length }}）</summary>
      <ol class="status-events__list">
        <li v-for="(item, index) in timeline" :key="index">
          <span class="status-events__name">{{ STAGE_LABELS[item.event] || item.event }}</span>
          <span class="status-events__detail">{{ item.data.reason || item.data.error || item.data.stage || '' }}</span>
        </li>
      </ol>
    </details>
  </section>
</template>
