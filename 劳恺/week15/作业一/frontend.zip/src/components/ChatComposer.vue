<script setup>
import { ref } from 'vue'

import { useConversationStore } from '@/stores/conversation'

const store = useConversationStore()
const draft = ref('')

function send() {
  const text = draft.value.trim()
  if (!text || store.streaming) return
  draft.value = ''
  store.sendMessage(text)
}
</script>

<template>
  <form class="composer" @submit.prevent="send">
    <textarea
      v-model="draft"
      class="composer__input"
      rows="3"
      placeholder="说点什么…（Enter 发送，Shift+Enter 换行）"
      :disabled="store.streaming"
      @keydown.enter.exact.prevent="send"
    />
    <button type="submit" class="button button--primary composer__send" :disabled="store.streaming || !draft.trim()">
      {{ store.streaming ? '执行中…' : '发送' }}
    </button>
  </form>
</template>
