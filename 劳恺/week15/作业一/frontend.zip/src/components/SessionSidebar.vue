<script setup>
import { useConversationStore } from '@/stores/conversation'

const store = useConversationStore()

function formatTime(value) {
  if (!value) return ''
  const date = new Date(value)
  const today = new Date()
  const sameDay = date.toDateString() === today.toDateString()
  return sameDay
    ? date.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })
    : date.toLocaleString('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' })
}
</script>

<template>
  <aside class="sidebar">
    <div class="sidebar__toolbar">
      <button type="button" class="button button--primary" @click="store.createConversation()">
        + 新建会话
      </button>
      <button type="button" class="button button--ghost" @click="store.loadConversations()">
        刷新
      </button>
    </div>

    <p v-if="!store.conversations.length" class="sidebar__empty">还没有会话</p>

    <ul class="session-list">
      <li
        v-for="item in store.conversations"
        :key="item.id"
        class="session-list__item"
        :class="{ 'is-active': item.id === store.activeId }"
        @click="store.selectConversation(item.id)"
      >
        <div class="session-list__main">
          <span class="session-list__title">{{ item.title }}</span>
          <span class="session-list__meta">
            {{ item.message_count }} 条 · {{ formatTime(item.updated_at) }}
          </span>
        </div>
        <button
          type="button"
          class="session-list__delete"
          title="删除会话"
          @click.stop="store.deleteConversation(item.id)"
        >
          ×
        </button>
      </li>
    </ul>
  </aside>
</template>
