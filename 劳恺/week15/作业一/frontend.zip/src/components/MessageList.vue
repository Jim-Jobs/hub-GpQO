<script setup>
import { nextTick, ref, watch } from 'vue'

import { useConversationStore } from '@/stores/conversation'

const store = useConversationStore()
const scroller = ref(null)

const EMOTION_LABELS = {
  positive: '正向',
  negative: '负向',
}

const STRATEGY_LABELS = {
  encouragement: '鼓励',
  empathy: '共情',
  support: '安全支持',
}

watch(
  () => [store.messages.length, store.streaming],
  async () => {
    await nextTick()
    if (scroller.value) {
      scroller.value.scrollTop = scroller.value.scrollHeight
    }
  },
)
</script>

<template>
  <div ref="scroller" class="message-list">
    <div v-if="!store.messages.length" class="message-list__empty">
      <p class="message-list__empty-title">开始一次对话</p>
      <p class="message-list__empty-hint">
        系统会先识别情绪，再据此生成共情或支持性的回复。
      </p>
    </div>

    <article
      v-for="message in store.messages"
      :key="message.id"
      class="message"
      :class="message.role === 'user' ? 'message--user' : 'message--assistant'"
    >
      <div class="message__role">{{ message.role === 'user' ? '我' : '助手' }}</div>

      <div class="message__bubble">
        <p class="message__content">{{ message.content }}</p>

        <div v-if="message.emotion" class="message__tags">
          <span class="tag" :class="`tag--${message.emotion.emotion}`">
            {{ EMOTION_LABELS[message.emotion.emotion] || message.emotion.emotion }}
          </span>
          <span v-if="message.emotion.emotion_type" class="tag tag--muted">
            {{ message.emotion.emotion_type }}
          </span>
          <span class="tag tag--muted">
            置信度 {{ (message.emotion.confidence * 100).toFixed(0) }}%
          </span>
          <span v-if="message.strategy" class="tag tag--muted">
            策略：{{ STRATEGY_LABELS[message.strategy] || message.strategy }}
          </span>
          <span v-if="message.used_fallback" class="tag tag--warning">兜底回复</span>
        </div>
      </div>
    </article>
  </div>
</template>
