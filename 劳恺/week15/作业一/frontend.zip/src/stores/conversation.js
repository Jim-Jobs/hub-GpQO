import { defineStore } from 'pinia'

import { streamChat } from '@/api/chat'
import { apiFor } from '@/api/client'

/** SSE 事件名 -> 中文标签，用于执行过程展示。 */
export const STAGE_LABELS = {
  started: '开始',
  emotion_analysis: '情绪识别',
  emotion_completed: '情绪识别完成',
  response_generation: '情绪响应',
  quality_check: '质量检查',
  retrying: '重试',
  completed: '完成',
  failed: '失败',
}

export const useConversationStore = defineStore('conversation', {
  state: () => ({
    /** 当前使用的框架版本。 */
    framework: 'langgraph',
    conversations: [],
    activeId: null,
    messages: [],
    /** 当前这一轮的 Agent 执行事件。 */
    timeline: [],
    streaming: false,
    error: '',
  }),

  getters: {
    activeConversation(state) {
      return state.conversations.find((item) => item.id === state.activeId) || null
    },
  },

  actions: {
    api() {
      return apiFor(this.framework)
    },

    /** 切换框架：两套框架的会话库互相独立，需要重新加载。 */
    async switchFramework(framework) {
      if (framework === this.framework) return
      this.framework = framework
      this.conversations = []
      this.activeId = null
      this.messages = []
      this.timeline = []
      this.error = ''
      await this.loadConversations()
    },

    async loadConversations() {
      try {
        const { data } = await this.api().get('/api/conversations')
        this.conversations = data
      } catch (error) {
        this.error = `无法连接后端服务：${error.message}`
      }
    },

    async selectConversation(id) {
      try {
        const { data } = await this.api().get(`/api/conversations/${id}`)
        this.activeId = data.id
        this.messages = data.messages
        this.timeline = []
        this.error = ''
      } catch (error) {
        this.error = `加载会话失败：${error.message}`
      }
    },

    async createConversation() {
      const { data } = await this.api().post('/api/conversations', {})
      this.conversations.unshift(data)
      this.activeId = data.id
      this.messages = []
      this.timeline = []
      this.error = ''
      return data
    },

    async deleteConversation(id) {
      try {
        await this.api().delete(`/api/conversations/${id}`)
        this.conversations = this.conversations.filter((item) => item.id !== id)
        if (this.activeId === id) {
          this.activeId = null
          this.messages = []
          this.timeline = []
        }
      } catch (error) {
        this.error = `删除会话失败：${error.message}`
      }
    },

    /** 发送消息，实时消费 SSE 事件。 */
    async sendMessage(text) {
      const content = (text || '').trim()
      if (!content || this.streaming) return

      this.streaming = true
      this.error = ''
      this.timeline = []

      const localId = `local-${Date.now()}`
      this.messages.push({
        id: localId,
        role: 'user',
        content,
        created_at: new Date().toISOString(),
      })

      try {
        await streamChat({
          framework: this.framework,
          conversationId: this.activeId,
          message: content,
          onEvent: ({ event, data }) => this.handleEvent(event, data),
        })
      } catch (error) {
        this.error = error.message
        this.timeline.push({ event: 'failed', data: { error: error.message } })
      } finally {
        this.streaming = false
        await this.loadConversations()
      }
    },

    handleEvent(event, data) {
      this.timeline.push({ event, data })

      if (event === 'started' && data.conversation_id) {
        this.activeId = data.conversation_id
      }

      if (event === 'completed') {
        this.messages.push({
          id: `assistant-${Date.now()}`,
          role: 'assistant',
          content: data.reply,
          emotion: data.emotion,
          strategy: data.strategy,
          quality: data.quality,
          used_fallback: data.used_fallback,
          created_at: new Date().toISOString(),
        })
      }

      if (event === 'failed') {
        this.error = data.error || '执行失败'
      }
    },
  },
})
