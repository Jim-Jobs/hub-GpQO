import { createRouter, createWebHistory } from 'vue-router'

import ChatView from '@/views/ChatView.vue'

const routes = [
  { path: '/', redirect: '/chat' },
  { path: '/chat', name: 'chat', component: ChatView },
  {
    path: '/experiments',
    name: 'experiments',
    component: () => import('@/views/ExperimentsView.vue'),
  },
]

export default createRouter({
  history: createWebHistory(),
  routes,
})
