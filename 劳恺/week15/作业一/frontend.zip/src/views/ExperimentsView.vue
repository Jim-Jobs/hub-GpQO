<script setup>
/** 实验结果页面占位：后续由实验脚本产出 JSON/CSV，再由 FastAPI 提供查询接口。 */
</script>

<template>
  <div class="placeholder-page">
    <h2>实验结果</h2>
    <p class="placeholder-page__lead">
      本页面为实验统计预留入口。当前阶段只实现核心业务系统，实验脚本与结果查询接口尚未接入。
    </p>
    <div class="placeholder-page__card">
      <h3>规划中的能力</h3>
      <ul>
        <li>批量运行两套框架并记录每次调用的延迟、token 与结果。</li>
        <li>导出 JSON / CSV 实验数据。</li>
        <li>由 FastAPI 提供统计查询接口，前端展示情绪分布与策略分布对比。</li>
      </ul>
    </div>
  </div>
</template>
