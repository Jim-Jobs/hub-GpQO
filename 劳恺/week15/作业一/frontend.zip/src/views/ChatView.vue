<script setup>
import { onMounted } from 'vue'

import AgentStatusPanel from '@/components/AgentStatusPanel.vue'
import ChatComposer from '@/components/ChatComposer.vue'
import MessageList from '@/components/MessageList.vue'
import SessionSidebar from '@/components/SessionSidebar.vue'
import { useConversationStore } from '@/stores/conversation'

const store = useConversationStore()

onMounted(() => {
  if (!store.conversations.length) {
    store.loadConversations()
  }
})
</script>

<template>
  <div class="chat-layout">
    <SessionSidebar class="chat-layout__sidebar" />

    <section class="chat-layout__main">
      <AgentStatusPanel class="chat-layout__status" />

      <MessageList class="chat-layout__messages" />

      <div v-if="store.error" class="chat-error">{{ store.error }}</div>

      <ChatComposer class="chat-layout__composer" />
    </section>
  </div>
</template>
