<script setup>
import { onMounted } from 'vue'
import { RouterLink, RouterView } from 'vue-router'

import { FRAMEWORK_LIST } from '@/api/framework'
import { useConversationStore } from '@/stores/conversation'

const store = useConversationStore()

onMounted(() => {
  store.loadConversations()
})
</script>

<template>
  <div class="app-shell">
    <header class="app-header">
      <div class="app-brand">
        <span class="app-brand__mark">Emotion</span>
        <span class="app-brand__text">情感识别与情绪响应多 Agent 系统</span>
      </div>

      <nav class="app-nav">
        <RouterLink to="/chat">聊天</RouterLink>
        <RouterLink to="/experiments">实验结果</RouterLink>
      </nav>

      <div class="framework-switch" role="group" aria-label="Agent 框架切换">
        <button
          v-for="item in FRAMEWORK_LIST"
          :key="item.key"
          type="button"
          class="framework-switch__button"
          :class="{ 'is-active': store.framework === item.key }"
          @click="store.switchFramework(item.key)"
        >
          {{ item.label }}
        </button>
      </div>
    </header>

    <main class="app-main">
      <RouterView />
    </main>
  </div>
</template>
